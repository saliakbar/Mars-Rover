﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mars_Rover
{
    public class Rover
    {
        public string Name { get; set; }
        public Direction Direction { get; set; }
        public Cordinates Cordinates { get; set; }

        public Rover(string name, Direction direction, Cordinates cordinates)
        {
            this.Name = name;
            this.Cordinates = cordinates;
            this.Direction = direction;
        }
        public void Left()
        {
            this.Direction = (Direction)((((int)this.Direction - 1) + 4) % 4);
        }

        public void Right()
        {
            this.Direction = (Direction)((((int)this.Direction + 1) + 4) % 4);
        }

        public void Move()
        {
            switch (Direction)
            {
                case Direction.North:
                    this.Cordinates.Y++;
                    break;
                case Direction.East:
                    this.Cordinates.X++;
                    break;
                case Direction.South:
                    this.Cordinates.Y--;
                    break;
                case Direction.West:
                    this.Cordinates.X--;
                    break;
            }
        }
        public void UndoMove()
        {
            switch (Direction)
            {
                case Direction.North:
                    this.Cordinates.Y--;
                    break;
                case Direction.East:
                    this.Cordinates.X--;
                    break;
                case Direction.South:
                    this.Cordinates.Y++;
                    break;
                case Direction.West:
                    this.Cordinates.X++;
                    break;
            }
        }
    }
}
