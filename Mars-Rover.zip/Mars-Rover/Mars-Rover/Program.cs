﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mars_Rover
{
    class Program
    {
        public static Rover[,] Plateu;
        static void Main(string[] args)
        {

            try
            {
                Console.WriteLine("Enter Platue Length");
                int length = Convert.ToInt32(Console.ReadLine());//Y

                Console.WriteLine("Enter Platue Width");
                int width = Convert.ToInt32(Console.ReadLine());//X

                Plateu = new Rover[length, width];

                Console.WriteLine("Enter Number of Rovers:");
                int roverCount = Convert.ToInt32(Console.ReadLine());

                Rover[] rovers = new Rover[roverCount];

                for (int i = 0; i < roverCount; i++)
                {
                    Console.WriteLine("Enter Rover{0} Landing in form of X,Y,Direction e.g. 0,1,N", (i + 1));
                    string roverlanding = Console.ReadLine();
                    string[] roverlandingsplit = roverlanding.Split(',');//Spliting input 0,1,N 
                    int x = Convert.ToInt32(roverlandingsplit[0]);
                    int y = Convert.ToInt32(roverlandingsplit[1]);
                    char direction = Convert.ToChar(roverlandingsplit[2]);
                    try
                    {
                        if (Plateu[x, y] != null)//Another rover is already here
                        {
                            Console.WriteLine("Can't land at this location, a rover already exist. Please reenter");
                            i--;
                            continue;
                        }
                    }
                    catch (IndexOutOfRangeException)//landing location out of range
                    {
                        Console.WriteLine("Landing location out of range. Please reenter");
                        i--;
                        continue;
                    }

                    rovers[i] = new Rover("Rover" + (i + 1), GetDirection(direction), new Cordinates() { X = x, Y = y });
                    Plateu[x, y] = rovers[i];

                    Console.WriteLine("Enter Rover{0} Instructions e.g. RLLLMMMLRML", (i + 1));
                    string roverInstructions = Console.ReadLine();
                    foreach (char instruction in roverInstructions)
                    {
                        ProcessInstruction(ref rovers[i], instruction);
                    }
                }

                foreach (Rover rover in rovers)
                {
                    Console.WriteLine("{0}:{1} {2} {3}", rover.Name, rover.Cordinates.X, rover.Cordinates.Y, rover.Direction.ToString().Substring(0, 1));
                }


                Console.Read();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.Read();
            }

        }

        private static Direction GetDirection(char dir)
        {
            switch (dir)
            {
                case 'N':
                case 'n':
                    return Direction.North;
                case 'S':
                case 's':
                    return Direction.South;
                case 'E':
                case 'e':
                    return Direction.East;
                case 'W':
                case 'w':
                    return Direction.West;
            }
            throw new Exception("Invalid Direcion");
        }

        public static Rover ProcessInstruction(ref Rover rover, char instruction)
        {
            switch (instruction)
            {
                case 'L':
                case 'l':
                    rover.Left();
                    break;
                case 'R':
                case 'r':
                    rover.Right();
                    break;
                case 'M':
                case 'm':
                    try
                    {
                        Plateu[rover.Cordinates.Y, rover.Cordinates.X] = null;
                        rover.Move();
                        if (Plateu[rover.Cordinates.Y, rover.Cordinates.X] != null)
                        {
                            throw new Exception("Location Already Occupied");
                        }
                        Plateu[rover.Cordinates.Y, rover.Cordinates.X] = rover;

                    }
                    catch (IndexOutOfRangeException)
                    {
                        //Console.WriteLine("No Place to Move,move cancelled");
                        rover.UndoMove();
                        Plateu[rover.Cordinates.Y, rover.Cordinates.X] = rover;
                    }
                    catch (Exception)
                    {
                        //Console.WriteLine("Crash threat move cancelled");
                        rover.UndoMove();
                        Plateu[rover.Cordinates.Y, rover.Cordinates.X] = rover;
                    }
                    break;
            }
            return rover;
        }


    }
}
